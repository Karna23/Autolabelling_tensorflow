from sklearn.model_selection import train_test_split
import pathlib
import os
import shutil

def preprocess_dir(path_to_dir):
    #directory=os.path.dirname(path_to_dir)
    if not os.path.exists(path_to_dir):
        os.makedirs(path_to_dir)
    else:
        remove_all_files(path_to_dir)
        
def remove_all_files(path_to_dir):
    for filename in os.listdir(path_to_dir):
        file_path = os.path.join(path_to_dir, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print('Failed to delete %s. Reason: %s' % (file_path, e))

def copy_images(label_list, path_to_folder):
    for file in label_list:
        #try:
        shutil.copy(file, path_to_folder)
        #except:
        #    print('copy_images: CAN NOT COPY FILE: ',file)

def split_images(path_to_dir, path_to_train_folder, path_to_test_folder, train_size=0.9):        
      
    path_to_train_folder=pathlib.Path(path_to_train_folder)
    path_to_test_folder=pathlib.Path(path_to_test_folder)
    path_to_dir=pathlib.Path(path_to_dir)

    imgs_list=list(path_to_dir.glob('*.jpg'))
    train_size=train_size
    test_size=(1-train_size)

    train_labels, test_labels=train_test_split(imgs_list, shuffle=True, train_size=train_size, test_size=test_size, random_state=0)

    preprocess_dir(path_to_train_folder)
    preprocess_dir(path_to_test_folder)
    
    copy_images(train_labels, path_to_train_folder)
    copy_images(test_labels, path_to_test_folder)

