import glob
import xml.etree.ElementTree as ET
import numpy as np
import pathlib, os, glob
import shutil
import pathlib
import cv2
from imgaug import augmenters as iaa
from tqdm import tqdm

class AnnoChanger():
    
    def __init__(self, path_to_folder):
        self.path_to_folder=path_to_folder    
    
    
    #replaces field name from field_name to new_field_name for all images
    def replace_fieldname(self, field_name, new_field_name):
        """
        
        field_name -- name of the field you want to change
        new_field_name -- new name of the field
        
        """
        
        for file in glob.glob(self.path_to_folder+'*.xml'):
            tree = ET.parse(file)
            
            root = tree.getroot()
            
            for field in root.findall('.//object//name'):
                if (field.text==field_name):
                    field.text=new_field_name
                    
            tree.write(file)
    
    #check if every image contains this field
    def check_fieldname(self, field_name):
        """
        
        field_name -- name of the field you want to check
        
        """
        
        list_of_filenames=glob.glob(self.path_to_folder+'*.xml')
        
        ALL_RIGHT_BOOL=True
        
        for file in list_of_filenames:
            tree = ET.parse(file)
            
            root = tree.getroot()
            
            field_names=np.array([obj.text for obj in root.findall('.//object//name')])
            
            if ((field_names==field_name).sum()==0):
                print('FILE '+file+' DOES NOT CONTAIN THIS FIELD')
                ALL_RIGHT_BOOL==False
                
        if ALL_RIGHT_BOOL:
            print('ALL FILES CONTAIN THIS FIELD')
            
        return ALL_RIGHT_BOOL
    
    def crop_sizes(self, x_crop_left, x_crop_right, y_crop_top, y_crop_bot):
        """
        
        x_crop_left -- number of pixels cropped from top left corner in pixels over X-axis
        x_crop_right -- number of pixels cropped from top right corner in pixels over X-axis
        
        y_crop_top -- number of pixels cropped from top left corner in pixels over Y-axis
        y_crop_bot -- number of pixels cropped from bottom left corner in pixels over Y-axis
        
        """
        
        for file in glob.glob(os.path.join(self.path_to_folder, '*.xml')):
            
            tree = ET.parse(file)
            
            root = tree.getroot()
            
            #adjusting height and width
            width, height, chanels=root.findall('.//size//')
            
            width.text=str(int(width.text) - (x_crop_left+x_crop_right))
            
            height.text=str(int(height.text) - (y_crop_top+y_crop_bot))
            
            #adjusting bbox coords
            bbox_coords=np.array([int(field.text) for field in root.findall('.//object//bndbox//')])
            
            #all x coords
            bbox_coords[::2]-=x_crop_left
            
            #all y coords
            bbox_coords[1::2]-=y_crop_top
            
            for num,field in enumerate(root.findall('.//object//bndbox//')): 
                field.text=str(bbox_coords[num])
                
            tree.write(file)
        
    def swap_xy(self,IMG_ROT_BOOL=False):
            
        """
        
        x_crop_left -- number of pixels cropped from top left corner in pixels over X-axis
        x_crop_right -- number of pixels cropped from top right corner in pixels over X-axis
        
        y_crop_top -- number of pixels cropped from top left corner in pixels over Y-axis
        y_crop_bot -- number of pixels cropped from bottom left corner in pixels over Y-axis
        
        """
        if (IMG_ROT_BOOL==True):
            for filename in glob.glob(self.path_to_folder+'*.jpg'):
                img=cv2.imread(filename)
                cv2.imwrite( filename,np.swapaxes(img, 0,1) )
        
        
        for file in glob.glob(os.path.join(self.path_to_folder,'*.xml')):
            
            tree = ET.parse(file)
            
            root = tree.getroot()
            
            #adjusting height and width
            width, height, chanels=root.findall('.//size//')
            
            width.text=str(height)
            
            height.text=str(width)
            
            #adjusting bbox coords
            bbox_coords=np.array([int(field.text) for field in root.findall('.//object//bndbox//')])
            
            #all x coords
            x_coords=bbox_coords[::2]
            
            #all y coords
            y_coords=bbox_coords[1::2]
            
            for num,field in enumerate(root.findall('.//object//bndbox//')): 
                if ((num % 2)==0):
                    field.text=str(y_coords[num//2])
                else: 
                    field.text=str(x_coords[num//2])
                
            tree.write(file)
            
    def multiply_anno(self, original_xml_filename):
        jpgs=list(glob.glob(os.path.join(self.path_to_folder, '*.jpg')))
        jpgs.sort()
        
        for jpg_filepath in jpgs[1:]:
            
            xml_filepath=jpg_filepath.replace('jpg', 'xml')
            
            jpg_filename=pathlib.Path(jpg_filepath).name
            
            xml_filename=jpg_filename.replace('jpg', 'xml')
            
            change_filename_in_xml(original_xml_filename, jpg_filename, xml_filepath)
                    
    
    def count_on_labelled_images(self):
        print("TOTAL AMOUNT OF XMLS: ", len(glob.glob(os.path.join( self.path_to_folder, "*.xml"))))
        
    def copy_labelled_images_to_folder(self, destination_folder):
        
        if not os.path.exists(destination_folder):
            os.makedirs(destination_folder)
        
        xml_list= glob.glob(os.path.join(self.path_to_folder,'*.xml'))
        
        for path_to_file in xml_list:
            filename=pathlib.Path(path_to_file).name
            shutil.copy(path_to_file, os.path.join(destination_folder, filename))
            shutil.copy(path_to_file[:-4]+".jpg", os.path.join(destination_folder, filename[:-4]+".jpg"))
            
    def copy_not_labelled_images_to_folder(self, path_to_labelled_folder, path_to_non_labelled):
        
        if not os.path.exists(path_to_non_labelled):
            os.makedirs(path_to_non_labelled)
        
        all_images_list=glob.glob(os.path.join(self.path_to_folder,'*.jpg'))
        #print(all_images_list)
        labelled_xml_list=glob.glob(os.path.join(path_to_labelled_folder,'*.xml'))
        
        labelled_images_list=[xml.replace('xml', 'jpg') for xml in labelled_xml_list]
        
        not_labelled_images_list=list(set(all_images_list)-set(labelled_images_list))
        
        for image in not_labelled_images_list:
            filename=pathlib.Path(image).name
            shutil.move(image, os.path.join(path_to_non_labelled, filename))
            
    def move_not_labelled_images_to_folder(self, path_to_non_labelled):
        
        if not os.path.exists(path_to_non_labelled):
            os.makedirs(path_to_non_labelled)
        
        all_images_list=glob.glob(os.path.join(self.path_to_folder,'*.jpg'))
        #print(all_images_list)
        labelled_xml_list=glob.glob(os.path.join(self.path_to_folder,'*.xml'))
        
        labelled_images_list=[xml.replace('xml', 'jpg') for xml in labelled_xml_list]
        
        not_labelled_images_list=list(set(all_images_list)-set(labelled_images_list))
        
        for image in not_labelled_images_list:
            filename=pathlib.Path(image).name
            shutil.move(image, os.path.join(path_to_non_labelled, filename))        
            
    def move_images_without_order_data(self, path_to_new_folder_wo_order_data, order_data): 
    
        if not os.path.exists(path_to_new_folder_wo_order_data):
            os.makedirs(path_to_new_folder_wo_order_data)
        
        all_images_list=glob.glob(os.path.join(self.path_to_folder,'*.jpg'))
        all_xmls_list=glob.glob(os.path.join(self.path_to_folder,'*.xml'))

        order_data_vins = []
        for d in order_data:
            order_data_vins.append(d["vin7"])
            
        img_vins = []        
        for file in all_images_list:
            vin=str(pathlib.Path(file).name).split('_')[0][-7:]
            img_vins.append(vin)
            
        list_vins_wo_order_data = list(set(img_vins) - set(img_vins).intersection(order_data_vins))
            
   
        #not_labelled_images_list = list(set(all_images_list)-set(labelled_images_list))
        
        for img_vin in list_vins_wo_order_data:
            for image in all_images_list:
                if img_vin in image:
                    filename=pathlib.Path(image).name
                    shutil.move(image, os.path.join(path_to_new_folder_wo_order_data, filename))
                    
        for img_vin in list_vins_wo_order_data:
            for xml in all_xmls_list:
                if img_vin in xml:
                    filename=pathlib.Path(xml).name
                    shutil.move(xml, os.path.join(path_to_new_folder_wo_order_data, filename))
    
    
    #copies annotations from annotations_source_folder to self.path_to_folder
    def copy_annotations_to_folder(self, annotations_source_folder):
        
        for image in glob.glob(os.path.join(self.path_to_folder, '*.jpg')):
            
            image_name=pathlib.Path(image).name
            
            shutil.copy(os.path.join(annotations_source_folder,image_name[:-4]+'.xml'), os.path.join(self.path_to_folder,image_name[:-4]+'.xml') )
        
    def copy_images_to_folder(self, annotations_source_folder):
        
        for image in glob.glob(os.path.join(self.path_to_folder, '*.jpg')):            
            image_name=pathlib.Path(image).name            
            shutil.copy(os.path.join(annotations_source_folder,image_name), os.path.join(self.path_to_folder,image_name)) 
            

    def crop_images_from_annotations(self, path_to_cropped_folder, label_names):        
        for label_name in label_names:
            if not os.path.exists(os.path.join(path_to_cropped_folder, label_name)):
                os.makedirs(os.path.join(path_to_cropped_folder, label_name))        

        LENGTH_OF_RECORD=9

        for xml_file in tqdm(glob.glob(os.path.join(self.path_to_folder,'*.xml'))):
            tree = ET.parse(xml_file)
            root=tree.getroot()
            data=root.findall('.//object//')
            xml_filename=pathlib.Path(xml_file).name
 
            for i, record in enumerate([data[i:i+LENGTH_OF_RECORD] for i in range(0, len(data), LENGTH_OF_RECORD)]):
                try:
                    for name in label_names: 
                        if (record[0].text == name):
                            image=cv2.imread(xml_file[:-4]+'.jpg')
                            ymin=int(record[6].text)
                            ymax=int(record[8].text)
                            xmin=int(record[5].text)
                            xmax=int(record[7].text)
#                             print(i)                            
                            crop_path = os.path.join(path_to_cropped_folder, name, xml_filename[:-4] + "_" + str(i) + '.jpg')
                            cv2.imwrite(crop_path, image[ymin:ymax, xmin:xmax])
                except:
                    print("NOK", xml_filename)
    
    def crop_bboxes_from_annotations(self, path_to_cropped_folder, label_name): 
        pass
        LENGTH_OF_RECORD=9
        #print(glob.glob(os.path.join(self.path_to_folder,'*.xml')))
        for xml_file in glob.glob(os.path.join(self.path_to_folder,'*.xml')):
            tree = ET.parse(xml_file)
            #print(xml_file)       
            root = tree.getroot()
            data=root.findall("object")
            xml_filename=pathlib.Path(xml_file).name  
            #for name in obj.findall("name"): 
            #print([data[i:i+LENGTH_OF_RECORD] for i in range(0, len(data), LENGTH_OF_RECORD)])
            for i,record in enumerate([data[i:i+LENGTH_OF_RECORD] for i in range(0, len(data), LENGTH_OF_RECORD)]):
                print(record[0].text)
                try:
                    if (record[0].text==label_name):                       
                        image=cv2.imread(xml_file[:-4]+'.jpg')
                        ymin=int(record[6].text)
                        ymax=int(record[8].text)                  
                        xmin=int(record[5].text)
                        xmax=int(record[7].text)
                        print(os.path.join(path_to_cropped_folder,xml_filename[:-4]+'_'+str(i)+'.jpg'))
                        cv2.imwrite(os.path.join(path_to_cropped_folder,xml_filename[:-4]+'_'+str(i)+'.jpg'), image[ymin:ymax, xmin:xmax])
                except:
                    print(xml_file)
                
    def get_bbox_areas(self,field_name="cap"):
        areas={}
        areas_list=[]
        LENGTH_OF_RECORD=9
        
        for file in glob.glob(os.path.join(self.path_to_folder, '*.xml')):
            #print(file)
            tree = ET.parse(file)
            
            root = tree.getroot()
            
            data=root.findall('.//object//')
            xml_filename=pathlib.Path(file).name
            areas[file]=[]
            for i,record in enumerate([data[i:i+LENGTH_OF_RECORD] for i in range(0, len(data), LENGTH_OF_RECORD)]):
                
                if (record[0].text==field_name):
                    ymin=int(record[6].text)
                    ymax=int(record[8].text)
                
                    xmin=int(record[5].text)
                    xmax=int(record[7].text)
            
                    areas[file].append((xmax-xmin)*(ymax-ymin))
                    areas_list.append((xmax-xmin)*(ymax-ymin))
        return areas, areas_list
    
                
    def get_bbox_lens(self,field_name="cap"):
        areas=[]
        LENGTH_OF_RECORD=9
        lengts={}
        for file in glob.glob(os.path.join(self.path_to_folder, '*.xml')):
            #print(file)
            tree = ET.parse(file)
            
            root = tree.getroot()
            
            data=root.findall('.//object//')
            xml_filename=pathlib.Path(file).name
            counter=0
            for i,record in enumerate([data[i:i+LENGTH_OF_RECORD] for i in range(0, len(data), LENGTH_OF_RECORD)]):                
                #if (record[0].text==field_name):
                counter+=1
            #print(counter)        
            if counter>12:
                #shutil.move(file, 'C:\\Users\\QXZ1TLW\\Projects\\P01.H18.B20.Variant_fuel_coduit\\images_iter_2\\tst\\')
                #shutil.move(file.replace('xml', 'jpg'), 'C:\\Users\\QXZ1TLW\\Projects\\P01.H18.B20.Variant_fuel_coduit\\images_iter_2\\tst\\')               
                print('ERROR: ', file)
        #return areas    
    
    
    def change_filename_in_xml(path_to_original_xml_file, new_filename, new_full_path):

        tree = ET.parse(path_to_original_xml_file)

        root = tree.getroot()

        root.findall('.//filename')[0].text=new_filename
        #VIN-WBY11CF000CJ11381_I20_11CF_Image-0001_78d4a51c-5d3b-44d5-95ad-23d67d29b99d.jpg
        tree.write(new_full_path)            
            