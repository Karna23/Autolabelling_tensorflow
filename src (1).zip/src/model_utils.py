import pathlib
import tensorflow as tf

def load_model(model_name):
    
    model_dir = pathlib.Path(model_name)/"saved_model"
    model = tf.saved_model.load(str(model_name))
    
    model.signatures['serving_default'].inputs
    model.signatures['serving_default'].output_dtypes
    model.signatures['serving_default'].output_shapes
    print("Model Loaded")
    
    return model