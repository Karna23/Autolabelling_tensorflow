import xml 
import xml.etree.ElementTree
import pathlib
import glob 
from object_detection.utils import ops as utils_ops
from object_detection.utils import label_map_util
from object_detection.utils import visualization_utils as vis_util
from src.model_utils import load_model
from tqdm.notebook import tqdm
import numpy as np
import os

from PIL import Image

import tensorflow as tf


from src.object_detection_inference import get_classes_name_and_scores

from src.object_detection_inference import run_inference_for_single_image

class Annotator():
    
    def __init__(self, model_name, path_to_labels, image_folder, scores_threshold):
        self.model_name=model_name
        self.path_to_labels=path_to_labels
        self.image_folder=image_folder
        self.scores_threshold=scores_threshold
        
        self.path_to_test_images_dir=""
        self.test_image_paths=[]
        
        self.initialize_image_list()
        self.category_index={}
        
        
    def initialize_image_list(self):
        self.path_to_test_images_dir = pathlib.Path(self.image_folder)
        self.test_image_paths=sorted(list(self.path_to_test_images_dir.glob("*.jpg")))
        
        assert len(self.test_image_paths)!=0
        
    # dont load the model every time, just load it outside before, and only reference to the loaded model    
    def initialize_model(self):
        self.category_index = label_map_util.create_category_index_from_labelmap(self.path_to_labels, use_display_name=True)
#         self.model=load_model(self.model_name)
        
    def annotate_images(self):
        for image_path in tqdm(self.test_image_paths):
            bboxes = show_inference(self.model_name, image_path, self.scores_threshold, self.category_index, self.image_folder)

def show_inference(model, image_path, min_score_thresh, category_index, IMAGE_FOLDER):
    skipper = 0
    stickers = []
    bounding_box_coordinates = []
    
    absolut_bounding_box_coordinates = []
    close_range = [1,1,0,0]
    # the array based representation of the image will be used later in order to prepare the
    # result image with boxes and labels on it.
    image_np = np.array(Image.open(image_path))
    
    #     image = np.array(Image.open(image_path))
    #     alpha = 1.5 # Contrast control (1.0-3.0)
    #     beta = -100 # Brightness control (0-100)
    #     image_np = cv2.convertScaleAbs(image, alpha=alpha, beta=beta)

    # Actual detection.
    output_dict = run_inference_for_single_image(model, image_np)
    # Visualization of the results of a detection.
    vis_util.visualize_boxes_and_labels_on_image_array(
        image_np,
        output_dict['detection_boxes'],
        output_dict['detection_classes'],
        output_dict['detection_scores'],
        category_index,
        instance_masks=output_dict.get('detection_masks_reframed', None),
        use_normalized_coordinates=True,
        line_thickness=8)    
    
    #scores = np.array([filtered_clamps_detections[i]['score'] for i in range(len(filtered_clamps_detections))])
    #boxes = get_bboxes_from_detections(filtered_clamps_detections, image_height, image_width)        
    
    # This is the way I'm getting my coordinates
    boxes = output_dict['detection_boxes']
    # get all boxes from an array
    max_boxes_to_draw = boxes.shape[0]
    # get scores to get a threshold
    scores = output_dict['detection_scores']
    # this is set as a default but feel free to adjust it to your needs
    #min_score_thresh=.5
    
    indices = tf.image.non_max_suppression(boxes, scores, max_output_size=10, iou_threshold=0.75)
    boxes = np.take(boxes, indices, axis=0)
    
    
    image_np = Image.fromarray(image_np)
    im_width, im_height = image_np.size
    
    # iterate over all objects found
    for i in range(min(max_boxes_to_draw, boxes.shape[0])):
        if scores is None or scores[i] > min_score_thresh:
            # boxes[i] is the box which will be drawn
            class_name = category_index[output_dict['detection_classes'][i]]['name']
            coordinates = boxes[i]
            if close_range[0] > coordinates[0]:
                close_range[0] = coordinates[0]
            if close_range[1] > coordinates[1]:
                close_range[1] = coordinates[1]
            if close_range[2] < coordinates[2]:
                close_range[2] = coordinates[2]
            if close_range[3] < coordinates[3]:
                close_range[3] = coordinates[3]
                
            bounding_box_coordinates.append(coordinates)
            xmin, xmax, ymin, ymax = (coordinates[0], coordinates[1], coordinates[2], coordinates[3])
            
            from_right = int(im_width * ymax)
            from_bottom = int(im_height * ymin)
            from_left = int(im_width * xmax)
            from_top = int(im_height * xmin)
            absolut_bounding_box_coordinates.append([class_name, from_left, from_top, from_right, from_bottom])
    
    try:
        boxes = [[int(box[1]), int(box[2]), int(box[3]), int(box[4])] for box in absolut_bounding_box_coordinates]
        # get all boxes from an array
        max_boxes_to_draw = len(boxes)
        # get scores to get a threshold
        
        scores = [scores[i] for i,box in enumerate(absolut_bounding_box_coordinates)]
        # this is set as a default but feel free to adjust it to your needs
        #min_score_thresh=.5
        
        indices = tf.image.non_max_suppression(boxes, scores, max_output_size=max_boxes_to_draw, iou_threshold=0.75)
        absolut_bounding_box_coordinates = np.take(absolut_bounding_box_coordinates, indices, axis=0)
        
        filename = str(image_path).split("/")[-1]
        
        annotater(
            input_filename=filename, 
            image_width=str(im_width), 
            image_height=str(im_height), 
            bboxes = absolut_bounding_box_coordinates, IMAGE_FOLDER=IMAGE_FOLDER)
                #display(cropped_image)
    except:
        print('problem with image: ', image_path)
        print('DETECTED_CLASSES', set(output_dict['detection_classes']) )
        print('Confidence: ', scores)

    bounding_box_coordinates = [list(item) for item in bounding_box_coordinates]
    
    overwatcher = (get_classes_name_and_scores
                   (output_dict['detection_boxes'],
                    output_dict['detection_classes'],
                    output_dict['detection_scores'],
                    category_index))

    for i in overwatcher[:]:
        stickers.append(i['name'])

    #image_np = Image.fromarray(image_np)
#   image = image_np.resize((800,500),Image.ANTIALIAS)
    #display(image_np)
    
#     xmin, xmax, ymin, ymax = (coordinates[0], coordinates[1], coordinates[2], coordinates[3])
#     im_width, im_height = image_np.size

#     (left, right, top, bottom) = (xmin * im_width, xmax * im_height, ymin * im_width, ymax * im_height)

#     from_right = im_width * ymax
#     from_bottom = im_height * ymin
#     from_left = im_width * xmax
#     from_top = im_height * xmin
#     cropped_image = image_np.crop((from_left, from_top, from_right, from_bottom))
    
    #display(cropped_image)

#     filename = str(image_path).split("/")[-1]
    
    #cropped_image.save("bulkheads/"+"cropped_"+filename, "JPEG")
    return absolut_bounding_box_coordinates        



def annotater(input_filename, image_width, image_height, bboxes, IMAGE_FOLDER):
    et = xml.etree.ElementTree.parse('/home/qxz2q9c/autolabel/label.xml')

    # Append new tag: <a x='1' y='abc'>body text</a>
    folder = xml.etree.ElementTree.SubElement(et.getroot(), 'folder')
    folder.text = 'None'
    filename = xml.etree.ElementTree.SubElement(et.getroot(), 'filename')
    filename.text = input_filename
    path = xml.etree.ElementTree.SubElement(et.getroot(), 'path')
    path.text = 'None'
    source = xml.etree.ElementTree.SubElement(et.getroot(), 'source')
    database = xml.etree.ElementTree.SubElement(source, 'database')
    database.text = 'Unknown'
    segmented = xml.etree.ElementTree.SubElement(et.getroot(), 'segmented')
    segmented.text = '0'
    imagesize = xml.etree.ElementTree.SubElement(et.getroot(), 'size')
    width = xml.etree.ElementTree.SubElement(imagesize, 'width')
    width.text = image_width
    height = xml.etree.ElementTree.SubElement(imagesize, 'height')
    height.text = image_height
    depth = xml.etree.ElementTree.SubElement(imagesize, 'depth')
    depth.text = '3'
    
    for bbox in bboxes:
        object_clause = xml.etree.ElementTree.SubElement(et.getroot(), 'object')
        name = xml.etree.ElementTree.SubElement(object_clause, 'name')
        name.text = bbox[0]
        pose = xml.etree.ElementTree.SubElement(object_clause, 'pose')
        pose.text = 'Unspecified'
        truncated = xml.etree.ElementTree.SubElement(object_clause, 'truncated')
        truncated.text = '0'
        difficult = xml.etree.ElementTree.SubElement(object_clause, 'difficult')
        difficult.text = '0'
        bndbox = xml.etree.ElementTree.SubElement(object_clause, 'bndbox')
        xmin = xml.etree.ElementTree.SubElement(bndbox, 'xmin')
        xmin.text = str(int(bbox[1]))
        ymin = xml.etree.ElementTree.SubElement(bndbox, 'ymin')
        ymin.text = str(int(bbox[2]))
        xmax = xml.etree.ElementTree.SubElement(bndbox, 'xmax')
        xmax.text = str(int(bbox[3]))
        ymax = xml.etree.ElementTree.SubElement(bndbox, 'ymax')
        ymax.text = str(int(bbox[4]))

    output_name = input_filename.split(".")[0] + ".xml"
    output_file = os.path.join(IMAGE_FOLDER, output_name)

    et.write(output_file)